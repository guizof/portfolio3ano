document.getElementById("Software").addEventListener("click", function() {
    window.location.href = "software.html";
});

document.getElementById("Modelagem").addEventListener("click", function() {
    window.location.href = "modelagem.html";
});

document.getElementById("Sistemas").addEventListener("click", function() {
    window.location.href = "sistemas.html";
});