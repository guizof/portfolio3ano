document.getElementById("Início").addEventListener("click", function() {
    window.location.href = "index.html";
});